import pandas as pd
import numpy as np
import re
from langchain_text_splitters import RecursiveCharacterTextSplitter
from langchain_core.documents import Document
from langchain_community.vectorstores import Chroma
from transformers import AutoTokenizer, AutoModel
import os
from openai import OpenAI, APIConnectionError, RateLimitError
import pickle
from langchain_community.vectorstores import Chroma
from langchain_community.vectorstores import FAISS
from langchain_core.vectorstores import InMemoryVectorStore
from langchain_openai import ChatOpenAI
from langchain_core.messages import HumanMessage, SystemMessage

# 1. Загрузка данных
train_data = pd.read_csv('train_data.csv')

# 2. Очистка текста от лишних символов
train_data['text'] = train_data['text'].astype(str).str[:-8]
def clean_text(text):
    # Удаляем символы Markdown (#, ** и др.) и прочие нетекстовые элементы
    text = re.sub(r'[#*]+', '', text)  # Удаляем # и *
    text = re.sub(r'\[.*?\]', '', text)  # Удаляем содержимое в квадратных скобках
    text = re.sub(r'\s+', ' ', text)  # Нормализуем пробелы
    text = text.strip()  # Удаляем лишние пробелы по краям
    return text

# Применяем очистку к столбцу 'text'
train_data['cleaned_text'] = train_data['text'].apply(clean_text)

# 2. Токенизатор и разбивка на чанки
try:
    tokenizer = AutoTokenizer.from_pretrained("sentence-transformers/all-MiniLM-L6-v2")
except Exception as e:
    print(f"Ошибка загрузки модели: {e}")
    exit(1)
# Функция для подсчёта токенов
def count_tokens(text):
    return len(tokenizer(text, truncation=False, padding=False)['input_ids'])

# 4. Разбивка текста на эмбеддинги (чанки)
text_splitter = RecursiveCharacterTextSplitter(
    chunk_size=625,  # Целевая длина в токенах
    chunk_overlap=55,  # Перекрытие в токенах
    length_function=count_tokens,  # Функция подсчёта длины
)

if os.path.exists("chunks_cache.pkl"):
    print("Загружаем сохранённые чанки...")
    with open("chunks_cache.pkl", "rb") as f:
        cached_chunks = pickle.load(f)
    # проверяем, что файл действительно содержит колонки id и chunks
    if isinstance(cached_chunks, pd.DataFrame):
        train_data = train_data.merge(cached_chunks, on='id', how='left')
    else:
        print("⚠️ Файл chunks_cache.pkl не в формате DataFrame, пересоздаём чанки...")
        cached_chunks = None
else:
    print("Файл с чанками не найден — создаём заново...")
    chunks_list = []
    for text in train_data['cleaned_text']:
        chunks = text_splitter.split_text(text)
        chunks_list.append(chunks)
    # Добавляем разбитые тексты обратно в DataFrame
    train_data['chunks'] = chunks_list
    # Кеш чанков
    with open("chunks_cache.pkl", "wb") as f:
        pickle.dump(train_data[['id', 'chunks']], f)



# 4. Подготовка документов
documents = []
for _, row in train_data.iterrows():
    for chunk in row['chunks']:
        metadata={"id": row['id'], 
                      "source": "train_data", 
                      "tags": row.get('tags', []), 
                      "annotation": row.get('annotation', "")}
        doc = Document(
            page_content=chunk, 
            metadata=metadata
            )
        documents.append(doc)

# 6. Формирование текстов для эмбеддинга
texts = [doc.page_content for doc in documents]

if not texts:
    print("Список texts пуст. Завершаем работу.")
    exit()

# 7. Функция для генерации эмбеддингов
client = OpenAI(
    base_url="https://ai-for-finance-hack.up.railway.app/",
    api_key="sk-k4GzLvBEsBYNbtVPpDaEMg"
)

def get_openai_embeddings(texts, model="text-embedding-3-small"):
    """Генерирует эмбеддинги через OpenAI API"""
    embeddings = []
    for i, text in enumerate(texts):
        if i % 10 == 0:  # Каждые 10 документов
            print(f"Обработка {i}/{len(texts)}...")
        try:
            response = client.embeddings.create(model=model, input=text, timeout=30)
            embeddings.append(response.data[0].embedding)
        except APIConnectionError as e:
            print(f"Ошибка подключения для текста {i}: {e}")
            embeddings.append([0.0] * 1536)
        except RateLimitError as e:
            print(f"Превышен лимит для текста {i}: {e}")
            embeddings.append([0.0] * 1536)
        except Exception as e:
            print(f"Неизвестная ошибка для текста {i}: {e}")
            embeddings.append([0.0] * 1536)
    return embeddings


BATCH_SIZE = 50
EMBEDDINGS_CACHE = "./embeddings_cache.pkl"

# 1. Загрузка кеша или начало с нуля
if os.path.exists(EMBEDDINGS_CACHE):
    print("Загружаем кешированные эмбеддинги...")
    with open(EMBEDDINGS_CACHE, "rb") as f:
        embeddings_array = pickle.load(f)
    # С какого индекса начинать следующую порцию
    start_idx = len(embeddings_array)
    print(f"Продолжаем с индекса {start_idx}")
else:
    embeddings_array = []
    start_idx = 0
    print(f"Начинаем генерацию эмбеддингов для {len(texts)} текстов...")

# 2. Обработка порциями
for i in range(start_idx, len(texts), BATCH_SIZE):
    # Берём порцию: от i до i + BATCH_SIZE (или до конца)
    batch = texts[i:i + BATCH_SIZE]
    print(f"Обработка порции {i}–{min(i + len(batch) - 1, len(texts) - 1)}...")
    
    batch_embeddings = []  # Здесь будут эмбеддинги текущей порции
    text_counter = 0  # Счётчик текстов внутри батча
    for text in batch:
        text_counter += 1
        if text_counter % 10 == 0:
            print(f"  Обработано {text_counter} текстов в текущем батче")
        try:
            response = client.embeddings.create(
                model="text-embedding-3-small",
                input=text,
                timeout=30
            )
            batch_embeddings.append(response.data[0].embedding)
        except Exception as e:
            print(f"Ошибка для текста: {e}")
            # Заглушка при ошибке (вектор из нулей)
            batch_embeddings.append([0.0] * 1536)
    
    # Добавляем обработанную порцию к общему массиву
    embeddings_array.extend(batch_embeddings)
    
    # Сохраняем прогресс в кеш
    with open(EMBEDDINGS_CACHE, "wb") as f:
        pickle.dump(embeddings_array, f)
    print(f"Сохранено {len(embeddings_array)} эмбеддингов")


print(f"Готово: сгенерировано {len(embeddings_array)} эмбеддингов")

doc_db = {}
for i, doc in enumerate(documents):
    doc_db[doc.metadata["id"]] = {
        "document": doc,
        "embedding": np.array(embeddings_array[i])  # numpy
    }

with open("doc_db.pkl", "wb") as f:
    pickle.dump(doc_db, f)


# ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++ #

# === 1. Загрузка базы документов (из предыдущего этапа) ===
with open("doc_db.pkl", "rb") as f:
    doc_db = pickle.load(f)

print(f"✅ Загружено документов: {len(doc_db)}")

# ================== 2. Вопрос пользователя СЮДА ПИСАТЬ ВОПРОС ===================
questions_df = pd.read_csv(
    'questions.csv',
    sep=None,  # автоопределение разделителя
    engine='python'  # требуется для auto-sep
)
print(f"📥 Загружено {len(questions_df)} вопросов из questions.csv")
# Полная очистка всех скрытых символов в названиях столбцов
questions_df.columns = (
    questions_df.columns
    .str.replace(r'[^\w\s]', '', regex=True)  # убираем невидимые и спецсимволы
    .str.strip()  # убираем пробелы по краям
)

# Проверяем, какие колонки реально есть:
print("📋 Найденные колонки:", list(questions_df.columns))


# === 3. Настройка OpenAI-клиентов ===
llm = ChatOpenAI(
    api_key="sk-BuwLErZ4eL4yTAjfQxLaIA",  # ключ для LLM
    base_url="https://ai-for-finance-hack.up.railway.app/",
    model="openrouter/mistralai/mistral-small-3.2-24b-instruct",
    temperature=0.2
)
emb_client = OpenAI(
    base_url="https://ai-for-finance-hack.up.railway.app/",
    api_key="sk-k4GzLvBEsBYNbtVPpDaEMg"
)

# === 4. Результаты будем сохранять сюда ===
results = []

# === 5. Проходим по всем вопросам ===
for idx, row in questions_df.iterrows():
    question_id = row['ID вопроса']
    user_question = row['Вопрос']
    print(f"\n===============================")
    print(f"🧩 Вопрос {question_id}: {user_question}")

  # === 5.1 Генерация эмбеддинга вопроса ===
    try:
        question_emb = emb_client.embeddings.create(
            model="text-embedding-3-small",
            input=user_question
        ).data[0].embedding
    except Exception as e:
        print(f"⚠️ Ошибка при генерации эмбеддинга: {e}")
        results.append([question_id, user_question, "", f"Ошибка: {e}"])
        continue


    # === 4. Поиск ближайших документов ===
    similarities = []
    for doc_id, doc_data in doc_db.items():
        a = np.array(question_emb)
        b = np.array(doc_data["embedding"])
        sim = np.dot(a, b) / (np.linalg.norm(a) * np.linalg.norm(b))
        similarities.append((doc_id, sim))

    # сортируем и фильтруем по порогу 0.8
    similarities = [s for s in similarities if s[1] >= 0.8]
    top_docs = sorted(similarities, key=lambda x: x[1], reverse=True)[:4]

    # если вообще ничего не прошло порог — возьмём 2 лучших по схожести
    if not top_docs:
        top_docs = sorted(similarities, key=lambda x: x[1], reverse=True)[:2]


    # === 5. Формируем контекст из ближайших документов ===
    context_parts = []
    for doc_id, sim in top_docs:
        doc = doc_db[doc_id]["document"]
        meta = doc.metadata
        block = (
            f"Текст: {doc.page_content}\n"
            f"Аннотация: {meta.get('annotation', '')}\n"
            f"Теги: {meta.get('tags', '')}"
        )
        context_parts.append(block)

    context = "\n\n".join(context_parts)


    # ====================== 6. Формируем промпт. СЮДА ВСТАВЛЯТЬ ПРОМТ ===========================
    system_prompt = (
        "Ты - премиум-консультант с 20-летним стажем в банке. Думай шаг за шагом и сравнивай контекст между собой. Контекст важен, ты должен сравнить его в несколько этапов. Естественно Отвечай на вопрос понятным языком. Все ответы должны быть на русском языке. Если в вопросе содержится много орфографических или пунктуационных ошибок, сначала попытайся максимально точно понять вопрос. Если из вопроса не понятна суть, ты должен попросить переформулировать вопрос в вежливой манере. Если клиент задает несколько вопросов, отвечай на них по очереди и разделяй ответы для удобного чтения. Формат ответа, его длина, стиль, пунктуация, орфография и структура должны совпадать с данными примерами вопрос-ответ. Ты не должен использовать разметку markdown и специальные символы. Если начинаешь ответ с нового пункта или структурируешь - пиши новые пункты с новой строки. Ты не должен решать за клиента что ему надо делать и не предлагай варианты выбора несколько раз. Ты должен учитывать роль банка в ответах и отвечать без повторов, без воды и с высокой плотностью содержания, не додумывай информацию. Если не можешь привести конкретный пример - не пиши его. Сначала проанализируй вопрос, затем сделай вывод на основе контекста, далее сформируй несколько вариантов ответа и проанализируй лучший из них. НИКОГДА не проси: пароли, CVV, SMS-коды, номера карт и любые личные данные в закрытом доступе. Если клиент называет - перенаправляй на реального оператора, если такой имеется, или предоставь данные банка для прямой связи с оператором. Аудитория, которая задает тебе вопросы может быть самая разная, всех полов и возрастов, между ними нет разницы и ты должен отвечать всем одинаково, не хамить, не использовать сленг, запрещено оскорблять пользователя, который задает вопрос. Ты должен отвечать без вступления и слэнга, четко на поставленный вопрос. Если вопрос не связан с банком и ответа на него нет в базе знаний - отвечай, что ты консультируешь по вопросам, относящимся к банку в вежливой манере и спроси есть ли вопрос, связанный с банком. Отвечай на вопросы без воды и четко. Пример вопросов: Вопрос: Как часто выплачивается купон по облигации? Возможный ответ: Процентная выплата по облигации, которую получает держатель облигации, обычно устанавливается в процентах годовых от номинала облигации. Купон может выплачиваться один или несколько раз в год. Купон обычно выплачивается на брокерский счет клиента. Вопрос: Как опционные стратегии утилизируют деривативный лимит? Возможный ответ: Лимит, который позволяет компании заключать сделки хеджирования без обеспечения. То же самое, что и FXD- лимит. Деривативный лимит необходим только в тех сделках хеджирования, по которым компания несет обязательства перед банком (форвард, collar, seagull, продажа опциона компанией). Деривативный лимит может быть установлен по упрощенному Digital-процессу или с проведением полного кредитного анализа отчетности компании. Установка деривативного лимита в рамках Digital-процесса занимает около 1 недели и требует предоставления упрощенного пакета документов из 1С. Установка деривативного лимита по стандартному процессу через лимитную заявку занимает около 1 месяца. Максимальный объем сделки хеджирования определяется размером деривативного лимита. Максимальный объем сделки равен размеру деривативного лимита, деленного на риск-вес. Риск-вес зависит от срока сделки и валютной пары. Чем длиннее срок - тем выше риск-вес. Деривативный лимит позволяет заключать сделки как в онлайн-банке, так и по телефону с трейдером. Компании необходимо обеспечить сумму продажи на счете списания до 18:00 даты расчетов по сделке, если не указано иное. Вопрос: Как изменение ключевой ставки влияет на цену облигации с фиксированной ставкой? Возможный ответ: Облигации, купон по которым установлен фиксированным значением. Например, купон может быть 5%, 10%. Обычно цена таких облигаций сильно зависит от ключевой ставки. Если ключевая ставка выше купона - цена облигации ниже. Если ключевая ставка ниже купона - цена облигации выше. Если ключевая ставка растет, цена облигации падает. Если ключевая ставка падает, цена облигации растет. Обычно, чем ближе срок погашения облигации, тем ближе цена облигации к номиналу. Вместе с вопросами есть Текст, который является основной информацией для ответа - это часть статьи. Аннотация это описание статьи. Теги обозначают связанную тему статьи. ")
    user_prompt = f"Контекст:\n{context}\n\nВопрос:\n{user_question}\n\nОтвет:" # сюда автоматически подтягивается контект и вопрос 

    # === 7. Отправляем запрос к LLM  ===
    print("\n🤖 Отправка запроса к модели...")
    try:
        messages = [
            SystemMessage(content=system_prompt),
            HumanMessage(content=user_prompt)
        ]
        response = llm.invoke(messages)
        answer_text = response.content.strip()
    except Exception as e:
        print(f"⚠️ Ошибка при получении ответа от модели: {e}")
        answer_text = f"Ошибка при обработке: {e}"

    # === 5.6 Сохраняем результат ===
    results.append([question_id, user_question, context, answer_text])

    print(f"✅ Ответ получен для вопроса {question_id}")

def print_prompt_info(prompt_text):
    tokens = count_tokens(prompt_text)
    print(f"📏 Длина промпта: {tokens} токенов")
print_prompt_info(system_prompt + user_prompt)

# === 6. Сохраняем всё в CSV ===
output_df = pd.DataFrame(results, columns=["ID вопроса", "Вопрос", "Контекст", "Ответ модели"])
output_df.to_csv("./data/answers.csv", index=False, encoding="utf-8-sig")
print("\n💾 Все ответы сохранены в ./data/answers.csv")

# Читаем файл
df = pd.read_csv('./data/answers.csv', encoding='utf-8')

# Удаляем столбец "Контекст"
df = df.drop(columns=['Контекст'])

# Переименовываем столбец "Ответ модели"
df = df.rename(columns={'Ответ модели': 'Ответы на вопрос'})

# Сохраняем очищенный файл
df.to_csv('submission.csv', index=False, encoding='utf-8')


# Проверяем размеры файла
print(f"\n📊 Информация о файле:")
print(f"Количество строк: {df.shape[0]}")
print(f"Количество столбцов: {df.shape[1]}")
print(f"Столбцы: {df.columns.tolist()}")
